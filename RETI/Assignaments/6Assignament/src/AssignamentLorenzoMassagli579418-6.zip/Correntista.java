import java.util.List;

public class Correntista {
    public String nome;
    public List<MovimentiCorrentista> movimenti;

    public Correntista(String nome) {
        this.nome = nome;
    }

    public Correntista() {}




}
