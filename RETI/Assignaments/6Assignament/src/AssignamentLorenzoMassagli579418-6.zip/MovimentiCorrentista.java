public class MovimentiCorrentista {
    public String data, causale;

    public MovimentiCorrentista(String data, String causale) {
        this.data = data;
        this.causale = causale;
    }

    public MovimentiCorrentista() {}


}
